#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets/QMainWindow>
#include <QCheckBox>
#include <QGroupBox>
#include <QLabel>
#include "ui_mainwindow.h"
#include "renderingwidget.h"

class MainWindow : public QMainWindow
{
	Q_OBJECT

public:
	MainWindow(QWidget *parent = 0);
	~MainWindow();

private:
	Ui::MainWindowClass ui;

private slots:
	void showMeshInfo(int nPoint, int nEdge, int nFace);
	void newFile();
	void open();
	bool save();
	bool saveAs();
	void about();
	void subprev();
	void subnext();
	void subonly();
	void averageonly();

private:
	void init();
    void createActions();
    void createMenus();
    void createToolBars();
    void createStatusBar();
	void createRenderGroup();

private:
	QAction							*action_new_;
	QAction							*action_open_;
	QAction							*action_save_;
	QAction							*action_saveas_;
	QAction							*action_close_;
	QAction							*action_exit_;
	QAction							*action_aboutqt_;
	QAction							*action_about_;
	QAction							*action_sub_prev_;
	QAction							*action_sub_next_;
	QAction							*action_sub_only_;
	QAction							*action_average_only_;

	QMenu							*menu_file_;
	QMenu							*menu_edit_;
	QMenu							*menu_help_;

	QToolBar						*toolbar_file_;
	QToolBar						*toolbar_edit_;
	QToolBar						*toolbar_sub_;

	QCheckBox						*checkbox_point_;
	QCheckBox						*checkbox_edge_;
	QCheckBox						*checkbox_face_;
	QCheckBox						*checkbox_mesh_;
	QCheckBox						*checkbox_light_;
	QCheckBox						*checkbox_axis_;
	QGroupBox						*groupbox_render_;

	RenderingWidget					*renderingwidget_;

	QLabel							*label_meshInfo_;
	QLabel							*label_operatorInfo_;
};

#endif // MAINWINDOW_H
