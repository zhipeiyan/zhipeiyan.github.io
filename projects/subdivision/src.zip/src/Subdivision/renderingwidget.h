#ifndef RENDERINGWIDGET_H
#define RENDERINGWIDGET_H

#include <QGLWidget>
#include <vector>
#include <Eigen/Core>
#include "ui_renderingwidget.h"

#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/Mesh/PolyMesh_ArrayKernelT.hh>
typedef OpenMesh::PolyMesh_ArrayKernelT<>  MyMesh;

class MainWindow;
class CArcBall;

class RenderingWidget : public QGLWidget
{
	Q_OBJECT

public:
	RenderingWidget(QWidget *parent = 0);
	~RenderingWidget();

private:
	Ui::RenderingWidget ui;

protected:
	void initializeGL();
	void resizeGL(int w, int h);
	void paintGL();
	void timerEvent(QTimerEvent *e);

	// mouse events
	void mousePressEvent(QMouseEvent *e);
	void mouseMoveEvent(QMouseEvent *e);
	void mouseReleaseEvent(QMouseEvent *e);
	void mouseDoubleClickEvent(QMouseEvent *e);
	void wheelEvent(QWheelEvent *e);

public:
	void keyPressEvent(QKeyEvent *e);
	void keyReleaseEvent(QKeyEvent *e);

signals:
	void meshInfo(int, int, int);
	void operatorInfo(QString);

private:
	void Render();
	void SetLight();

public slots:
	void ReadMesh();
    void WriteMesh();
	void updateMesh(MyMesh&);
    void subprev();
	void subnext();
	void subonly();
	void averageonly();


	void CheckDrawPoint(bool bv);
	void CheckDrawEdge(bool bv);
	void CheckDrawFace(bool bv);
	void CheckLight(bool bv);
	void CheckDrawAxis(bool bv);

private:	
	void DrawPoints(bool);
	void DrawEdge(bool);
	void DrawFace(bool);
	void DrawAxis(bool);
	void DrawXORRect();

	MyMesh subdivide(MyMesh);
	MyMesh average(MyMesh);

public:
	CArcBall					*ptr_arcball_;

	std::vector<MyMesh>			meshes_;

	// Texture
	GLuint						texture_[1];
	bool						is_load_texture_;

	// eye
	GLfloat						eye_distance_;
    Eigen::Vector3d             eye_goal_;
    Eigen::Vector3d             eye_direction_;
	QPoint						current_position_;
	QPoint						start_position_;

	// Render information
	bool						is_draw_point_;	
	bool						is_draw_edge_;
	bool						is_draw_face_;
	bool						has_lighting_;
	bool						is_draw_axis_;

	// Interactive
	bool						is_selecting_;
	bool						is_dragging_;

	bool						is_selectwithrect_; //false: single point ; true: point in rect
	//bool						is_selectagain_;
};

#endif // RENDERINGWIDGET_H
