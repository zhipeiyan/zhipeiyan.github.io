#include "mainwindow.h"

#include <QtWidgets>

MainWindow::MainWindow(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);

	setWindowTitle("Subdivision Surfaces");

	renderingwidget_ = new RenderingWidget(this);

	createActions();
    createMenus();
    createToolBars();
    createStatusBar();
	createRenderGroup();

	QVBoxLayout *layout_left = new QVBoxLayout;
	layout_left->addWidget(groupbox_render_);
	layout_left->addStretch(4);

	QHBoxLayout *layout_main = new QHBoxLayout;

	layout_main->addLayout(layout_left);
	layout_main->addWidget(renderingwidget_);
	layout_main->setStretch(1, 1);
	this->centralWidget()->setLayout(layout_main);
}

MainWindow::~MainWindow()
{

}

void MainWindow::createActions()
{
	action_new_ = new QAction(QIcon(":/MainWindow/Resources/images/new.png"), tr("&New"), this);
    action_new_->setShortcuts(QKeySequence::New);
    action_new_->setStatusTip(tr("Create a new file"));
    connect(action_new_, SIGNAL(triggered()), this, SLOT(newFile()));

    action_open_ = new QAction(QIcon(":/MainWindow/Resources/images/open.png"), tr("&Open..."), this);
    action_open_->setShortcuts(QKeySequence::Open);
    action_open_->setStatusTip(tr("Open an existing file"));
    connect(action_open_, SIGNAL(triggered()), this, SLOT(open()));

    action_save_ = new QAction(QIcon(":/MainWindow/Resources/images/save.png"), tr("&Save"), this);
    action_save_->setShortcuts(QKeySequence::Save);
    action_save_->setStatusTip(tr("Save the document to disk"));
    connect(action_save_, SIGNAL(triggered()), this, SLOT(save()));

    action_saveas_ = new QAction(tr("Save &As..."), this);
    action_saveas_->setShortcuts(QKeySequence::SaveAs);
    action_saveas_->setStatusTip(tr("Save the document under a new name"));
    connect(action_saveas_, SIGNAL(triggered()), this, SLOT(saveAs()));

    action_close_ = new QAction(tr("&Close"), this);
    action_close_->setShortcut(tr("Ctrl+W"));
    action_close_->setStatusTip(tr("Close this window"));
    connect(action_close_, SIGNAL(triggered()), this, SLOT(close()));

    action_exit_ = new QAction(tr("E&xit"), this);
    action_exit_->setShortcuts(QKeySequence::Quit);
    action_exit_->setStatusTip(tr("Exit the application"));
    connect(action_exit_, SIGNAL(triggered()), qApp, SLOT(closeAllWindows()));

    action_about_ = new QAction(tr("&About"), this);
    action_about_->setStatusTip(tr("Show the application's About box"));
    connect(action_about_, SIGNAL(triggered()), this, SLOT(about()));

    action_aboutqt_ = new QAction(tr("About &Qt"), this);
    action_aboutqt_->setStatusTip(tr("Show the Qt library's About box"));
    connect(action_aboutqt_, SIGNAL(triggered()), qApp, SLOT(aboutQt()));

	action_sub_prev_ = new QAction(tr("Undo"),this);
	action_sub_prev_->setStatusTip(tr("Previous step of subdivision"));
	connect(action_sub_prev_,SIGNAL(triggered()),this,SLOT(subprev()));

	action_sub_next_ = new QAction(tr("SubAndAver"), this);
	action_sub_next_->setStatusTip(tr("Next step of subdivision"));
	connect(action_sub_next_, SIGNAL(triggered()), this, SLOT(subnext()));

	action_sub_only_ = new QAction(tr("Subdivide"), this);
	action_sub_only_->setStatusTip(tr("Subdivide the mesh"));
	connect(action_sub_only_, SIGNAL(triggered()), this, SLOT(subonly()));

	action_average_only_ = new QAction(tr("Average"), this);
	action_average_only_->setStatusTip(tr("Average the mesh"));
	connect(action_average_only_, SIGNAL(triggered()), this, SLOT(averageonly()));
}

void MainWindow::createMenus()
{
    menu_file_ = menuBar()->addMenu(tr("&File"));
    menu_file_->addAction(action_new_);
    menu_file_->addAction(action_open_);
    menu_file_->addAction(action_save_);
    menu_file_->addAction(action_saveas_);
    menu_file_->addSeparator();
    menu_file_->addAction(action_close_);
    menu_file_->addAction(action_exit_);

    menu_edit_ = menuBar()->addMenu(tr("&Edit"));

    menuBar()->addSeparator();

    menu_help_ = menuBar()->addMenu(tr("&Help"));
    menu_help_->addAction(action_about_);
    menu_help_->addAction(action_aboutqt_);
}

void MainWindow::createToolBars()
{
    toolbar_file_ = addToolBar(tr("File"));
    toolbar_file_->addAction(action_new_);
    toolbar_file_->addAction(action_open_);
    toolbar_file_->addAction(action_save_);

    toolbar_edit_ = addToolBar(tr("Edit"));

	toolbar_sub_ = addToolBar(tr("Subdivision"));
	toolbar_sub_->addAction(action_sub_only_);
	toolbar_sub_->addAction(action_average_only_);
	toolbar_sub_->addAction(action_sub_next_);
	toolbar_sub_->addAction(action_sub_prev_);
}

void MainWindow::createStatusBar()
{
    //statusBar()->showMessage(tr("Ready"));

	label_meshInfo_ = new QLabel(QString("MeshInfo: Points: %1, Edges: %2, Faces: %3.").arg(0).arg(0).arg(0));
	label_meshInfo_->setAlignment(Qt::AlignCenter);
	label_meshInfo_->setMinimumSize(label_meshInfo_->sizeHint());

	label_operatorInfo_ = new QLabel();
	label_operatorInfo_->setAlignment(Qt::AlignVCenter);

	statusBar()->addWidget(label_meshInfo_);
	connect(renderingwidget_, SIGNAL(meshInfo(int ,int ,int)), this, SLOT(showMeshInfo(int ,int ,int)));

	statusBar()->addWidget(label_operatorInfo_);
	connect(renderingwidget_, SIGNAL(operatorInfo(QString)), label_operatorInfo_, SLOT(setText(QString)));
}

void MainWindow::createRenderGroup()
{
	checkbox_point_ = new QCheckBox(tr("Point"), this);
	connect(checkbox_point_, SIGNAL(clicked(bool)), renderingwidget_, SLOT(CheckDrawPoint(bool)));
	checkbox_point_->setChecked(true);

	checkbox_edge_ = new QCheckBox(tr("Edge"), this);
	connect(checkbox_edge_, SIGNAL(clicked(bool)), renderingwidget_, SLOT(CheckDrawEdge(bool)));
	checkbox_edge_->setChecked(true);

	checkbox_face_ = new QCheckBox(tr("Face"), this);
	connect(checkbox_face_, SIGNAL(clicked(bool)), renderingwidget_, SLOT(CheckDrawFace(bool)));
	checkbox_face_->setChecked(true);

	checkbox_light_ = new QCheckBox(tr("Light"), this);
	connect(checkbox_light_, SIGNAL(clicked(bool)), renderingwidget_, SLOT(CheckLight(bool)));
	checkbox_light_->setChecked(true);

	checkbox_axis_ = new QCheckBox(tr("Axis"), this);
	connect(checkbox_axis_, SIGNAL(clicked(bool)), renderingwidget_, SLOT(CheckDrawAxis(bool)));
	checkbox_axis_->setChecked(true);

	groupbox_render_ = new QGroupBox(tr("Render"), this);

	QVBoxLayout* render_layout = new QVBoxLayout(groupbox_render_);
	render_layout->addWidget(checkbox_point_); 
	render_layout->addWidget(checkbox_edge_);
	render_layout->addWidget(checkbox_face_);
	render_layout->addWidget(checkbox_light_);
	render_layout->addWidget(checkbox_axis_);
}

void MainWindow::showMeshInfo(int nPoint, int nEdge, int nFace)
{
	label_meshInfo_->setText(QString("MeshInfo: Points: %1, Edges: %2, Faces: %3.").arg(nPoint).arg(nEdge).arg(nFace));
}

void MainWindow::newFile()
{
    MainWindow *other = new MainWindow;
    other->move(x() + 40, y() + 40);
    other->show();
}

void MainWindow::open()
{
	renderingwidget_->ReadMesh();
}

bool MainWindow::save()
{
        return saveAs();
}

bool MainWindow::saveAs()
{
	renderingwidget_->WriteMesh();

    return true;
}

void MainWindow::about()
{
   QMessageBox::about(this, tr("About Subdivision Surfaces"),
	   tr("Demo for Howework #3 of CSCE 645. \n                                         --  Zhipei Yan"));
}

void MainWindow::subprev()
{
	renderingwidget_->subprev();
}

void MainWindow::subnext()
{
	renderingwidget_->subnext();
}

void MainWindow::subonly()
{
	renderingwidget_->subonly();
}

void MainWindow::averageonly()
{
	renderingwidget_->averageonly();
}