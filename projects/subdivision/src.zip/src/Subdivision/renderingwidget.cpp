#include "renderingwidget.h"
#include <gl\GLU.h>
#include "globalFunctions.h"
#include "ArcBall.h"
#include <QFileDialog>
#include <QKeyEvent>

RenderingWidget::RenderingWidget(QWidget *parent)
	: QGLWidget(parent), eye_distance_(5.0), 
	is_draw_point_(true), is_draw_edge_(true), is_draw_face_(true), has_lighting_(true), is_draw_axis_(true),
	is_selecting_(false), is_dragging_(false), is_selectwithrect_(false)//, is_selectagain_(false)
{
	ui.setupUi(this);

	setFocusPolicy(Qt::StrongFocus);

	ptr_arcball_ = new CArcBall(width(), height());

	is_load_texture_ = false;	

	eye_goal_[0] = eye_goal_[1] = eye_goal_[2] = 0.0;
	eye_direction_[0] = eye_direction_[1] = 0.0;
	eye_direction_[2] = 1.0;
}

RenderingWidget::~RenderingWidget()
{
	SafeDelete(ptr_arcball_);
}

void RenderingWidget::initializeGL()
{
	glClearColor(0.3, 0.3, 0.3, 0.0);
	glShadeModel(GL_SMOOTH);

	glEnable(GL_DOUBLEBUFFER);
    glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_POLYGON_SMOOTH);
	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
	glEnable(GL_DEPTH_TEST);
	glClearDepth(1);

	SetLight();

}

void RenderingWidget::resizeGL(int w, int h)
{
	h = (h == 0) ? 1 : h;

	ptr_arcball_->reSetBound(w, h);

	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(45.0, GLdouble(w) / GLdouble(h), 0.001, 1000);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void RenderingWidget::paintGL()
{
	glShadeModel(GL_SMOOTH);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	if (has_lighting_)
	{
		SetLight();
	}
	else
	{
		glDisable(GL_LIGHTING);
		glDisable(GL_LIGHT0);
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

    //register vec eyepos = eye_distance_*eye_direction_;
    Eigen::Vector3d eyepos = eye_distance_*eye_direction_;
	gluLookAt(eyepos[0], eyepos[1], eyepos[2],
		eye_goal_[0], eye_goal_[1], eye_goal_[2],
		0.0, 1.0, 0.0);
	glPushMatrix();

	glMultMatrixf(ptr_arcball_->GetBallMatrix());

	Render();
	glPopMatrix();
}

void RenderingWidget::timerEvent(QTimerEvent * e)
{
	updateGL();
}

void RenderingWidget::mousePressEvent(QMouseEvent *e)
{
	switch (e->button())
	{
	case Qt::LeftButton:
		if (!is_selecting_)
		{
			ptr_arcball_->MouseDown(e->pos());
		}
		else if (!is_selectwithrect_)
		{		
		}
		else
		{
			is_dragging_ = true;
		}

		break;

	case Qt::MidButton:
		current_position_ = e->pos();
		break;
	default:
		break;
	}

	start_position_ = e->pos();
	current_position_ = start_position_;

	updateGL();
}

void RenderingWidget::mouseMoveEvent(QMouseEvent *e)
{
	switch (e->buttons())
	{
		setCursor(Qt::ClosedHandCursor);
	case Qt::LeftButton:
		if (!is_selecting_)
		{
			ptr_arcball_->MouseMove(e->pos());
		}
		else if(is_selectwithrect_)
		{			
		}
		
		break;
	case Qt::MidButton:
		eye_goal_[0] -= 4.0*GLfloat(e->x() - current_position_.x()) / GLfloat(width());
		eye_goal_[1] += 4.0*GLfloat(e->y() - current_position_.y()) / GLfloat(height());
		current_position_ = e->pos();
		break;
	default:
		break;
	}

	updateGL();
}
void RenderingWidget::mouseDoubleClickEvent(QMouseEvent *e)
{
	switch (e->button())
	{
	case Qt::LeftButton:
		break;
	default:
		break;
	}
	updateGL();
}

void RenderingWidget::mouseReleaseEvent(QMouseEvent *e)
{
	current_position_ = e->pos();
	is_dragging_ = false;

	switch (e->button())
	{
	case Qt::LeftButton:
		if (!is_selecting_)
		{
			ptr_arcball_->MouseUp(e->pos());
			setCursor(Qt::ArrowCursor);
		}
		
		break;

	case Qt::RightButton:
		break;
	default:
		break;
	}
}

void RenderingWidget::wheelEvent(QWheelEvent *e)
{
	eye_distance_ += e->delta()*0.001;
	eye_distance_ = eye_distance_ < 0 ? 0 : eye_distance_;

	updateGL();
}

void RenderingWidget::keyPressEvent(QKeyEvent *e)
{    
	switch (e->key())
	{
	default:
		break;
	}
    update();
}

void RenderingWidget::keyReleaseEvent(QKeyEvent *e)
{
	switch (e->key())
	{
	case Qt::Key_A:
		break;
	default:
		break;
	}
}

void RenderingWidget::Render()
{
	DrawPoints(is_draw_point_);
	DrawEdge(is_draw_edge_);
	DrawFace(is_draw_face_);
	DrawAxis(is_draw_axis_);

	if(is_selecting_ && is_dragging_)
	{
		DrawXORRect();
	}
}

void RenderingWidget::SetLight()
{
	static GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
	static GLfloat mat_shininess[] = { 50.0 };
	static GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };
	static GLfloat white_light[] = { 0.8, 0.8, 0.8, 1.0 };
	static GLfloat lmodel_ambient[] = { 0.3, 0.3, 0.3, 1.0 };

	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
}

void RenderingWidget::updateMesh(MyMesh& mesh)
{
	mesh.request_face_normals();
	mesh.request_vertex_normals();
	mesh.update_normals();
	emit(meshInfo(mesh.n_vertices(), mesh.n_edges(), mesh.n_faces()));
}

void RenderingWidget::ReadMesh()
{
	QString filename = QFileDialog::getOpenFileName(this, tr("Open Mesh File"),
		//"..");
		".", tr("All supported formats (*.obj *.ply *.stl);;Wavefront Object (*.obj);;Standford Polygon (*.ply);;STL format (*.stl);;All files (*.*)"));

	if (filename.isEmpty())
	{
		emit(operatorInfo(QString("Read Mesh Failed!")));
		return;
	}

	MyMesh mesh;
	OpenMesh::IO::read_mesh(mesh, filename.toStdString());
	for(MyMesh::VertexIter v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); v_it++)
		mesh.set_point(v_it, mesh.point(v_it)/10.);
	updateMesh(mesh);
	meshes_.clear();
	meshes_.push_back(mesh);

	emit(operatorInfo(QString("Read Mesh from") + filename + QString(" Done")));
	updateGL();
}

void RenderingWidget::WriteMesh()
{
	if (meshes_.empty())
		return;

    QString filename = QFileDialog::getSaveFileName(this, tr("Save Mesh File"),
		".", tr("All supported formats (*.obj *.ply *.stl);;Wavefront Object (*.obj);;Standford Polygon (*.ply);;STL format (*.stl);;All files (*.*)"));

    if (filename.isEmpty())
        return;

	OpenMesh::IO::write_mesh(meshes_.back(), filename.toStdString());

    emit(operatorInfo(QString("Write Mesh to ") + filename + QString(" Done")));
}

void RenderingWidget::subonly()
{
	if (meshes_.empty())
		return;

	std::clock_t start = std::clock();
	MyMesh mesh = subdivide(meshes_.back());
	double duration = (std::clock() - start) / (double)CLOCKS_PER_SEC;
	emit(operatorInfo(QString("Processing time: %1s").arg(duration)));
	updateMesh(mesh);
	meshes_.push_back(mesh);

	updateGL();
}

void RenderingWidget::averageonly()
{
	if (meshes_.empty())
		return;

	std::clock_t start = std::clock();
	MyMesh mesh = average(meshes_.back());
	double duration = (std::clock() - start) / (double)CLOCKS_PER_SEC;
	emit(operatorInfo(QString("Processing time: %1s").arg(duration)));
	updateMesh(mesh);
	meshes_.push_back(mesh);

	updateGL();
}

void RenderingWidget::subprev()
{
	if (meshes_.size() <= 1)
		return;

	meshes_.pop_back();

	emit(meshInfo(meshes_.back().n_vertices(), meshes_.back().n_edges(), meshes_.back().n_faces()));

	updateGL();
}

void RenderingWidget::subnext()
{
	if (meshes_.empty())
		return;

	std::clock_t start = std::clock();
	MyMesh mesh = subdivide(meshes_.back());
	mesh = average(mesh);
	double duration = (std::clock() - start) / (double)CLOCKS_PER_SEC;
	emit(operatorInfo(QString("Processing time: %1s").arg(duration)));
	updateMesh(mesh);
	meshes_.push_back(mesh);

	updateGL();
}

MyMesh RenderingWidget::average(MyMesh mesh)
{
	std::vector<MyMesh::Point> centroids(mesh.n_faces());

	for(MyMesh::FaceIter f_it = mesh.faces_begin(); f_it != mesh.faces_end(); f_it++)
	{
		MyMesh::Point pt(0,0,0);
		int degree = 0;
		for(MyMesh::FaceVertexIter fv_it = mesh.fv_iter(f_it); fv_it.is_valid(); degree++, fv_it++)
			pt += mesh.point(*fv_it);
		pt /= degree;
		centroids[f_it->idx()] = pt;
	}

	for(MyMesh::VertexIter v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); v_it++)
	{
		MyMesh::Point pt(0,0,0);
		int degree = 0;
		for (MyMesh::VertexFaceIter vf_it = mesh.vf_iter(v_it); vf_it.is_valid(); degree++, vf_it++)
			pt += centroids[vf_it->idx()];
		pt /= degree;
		mesh.set_point(v_it, pt);
	}

	mesh.garbage_collection();

	return mesh;
}

MyMesh RenderingWidget::subdivide(MyMesh mesh)
{
	mesh.request_face_status();
	mesh.request_edge_status();
	mesh.request_vertex_status();

	std::vector<MyMesh::VertexHandle> newpoints(mesh.n_edges());

	for (MyMesh::EdgeIter e_it = mesh.edges_begin(); e_it != mesh.edges_end(); e_it++)
	{
		MyMesh::HalfedgeHandle heh=mesh.halfedge_handle(e_it,0);
		MyMesh::VertexHandle fromh = mesh.from_vertex_handle(heh);
		MyMesh::VertexHandle toh = mesh.to_vertex_handle(heh);
		MyMesh::Point pfrom = mesh.point(fromh);
		MyMesh::Point pto = mesh.point(toh);
		MyMesh::Point npt = (pfrom+pto)/2.;
		newpoints[e_it->idx()] = mesh.add_vertex(npt);
	}

	std::vector<std::vector<MyMesh::VertexHandle>> newfaces;
	newfaces.reserve(16*mesh.n_faces());
	for(MyMesh::FaceIter f_it = mesh.faces_begin(); f_it != mesh.faces_end(); f_it++)
	{
		std::vector<MyMesh::VertexHandle> vh8;
		MyMesh::FaceHalfedgeIter fh_it = mesh.fh_iter(f_it);
		for(;fh_it.is_valid();fh_it++)
		{
			vh8.push_back(mesh.from_vertex_handle(fh_it));
			vh8.push_back(newpoints[mesh.edge_handle(fh_it).idx()]);
		}
		assert(vh8.size()==8);
		MyMesh::VertexHandle vh = mesh.add_vertex((mesh.point(vh8[0])+mesh.point(vh8[2])+mesh.point(vh8[4])+mesh.point(vh8[6]))/4.);
		std::vector<MyMesh::VertexHandle> newface(4);
		newface[0]=vh8[0];
		newface[1]=vh8[1];
		newface[2]=vh;
		newface[3]=vh8[7];
		newfaces.push_back(newface);
		newface[0]=vh8[2];
		newface[1]=vh8[3];
		newface[2]=vh;
		newface[3]=vh8[1];
		newfaces.push_back(newface);
		newface[0]=vh8[4];
		newface[1]=vh8[5];
		newface[2]=vh;
		newface[3]=vh8[3];
		newfaces.push_back(newface);
		newface[0]=vh8[6];
		newface[1]=vh8[7];
		newface[2]=vh;
		newface[3]=vh8[5];
		newfaces.push_back(newface);

		mesh.delete_face(f_it,false);
	}
	for(int i=0;i<newfaces.size();i++)
	{
		mesh.add_face(newfaces[i]);
	}

	mesh.garbage_collection();
	return mesh;
}

void RenderingWidget::CheckDrawPoint(bool bv)
{
	is_draw_point_ = bv;
	updateGL();
}

void RenderingWidget::CheckDrawEdge(bool bv)
{
	is_draw_edge_ = bv;
	updateGL();
}

void RenderingWidget::CheckDrawFace(bool bv)
{
	is_draw_face_ = bv;
	updateGL();
}

void RenderingWidget::CheckLight(bool bv)
{
	has_lighting_ = bv;
	updateGL();
}

void RenderingWidget::CheckDrawAxis(bool bv)
{
	is_draw_axis_ = bv;
	updateGL();
}

void RenderingWidget::DrawPoints(bool bv)
{
	if (!bv)
		return;

	if (meshes_.empty())
		return;

    if (meshes_.back().n_vertices() == 0)
		return;

    glBegin(GL_POINTS);
	for(auto it = meshes_.back().vertices_begin(); it != meshes_.back().vertices_end(); it++)
	{
		MyMesh::Normal normal = meshes_.back().normal(*it);
		auto point = meshes_.back().point(*it);
		glNormal3fv(normal.data());
		glVertex3fv(point.data());
	}
	glEnd();
}

void RenderingWidget::DrawEdge(bool bv)
{
	if (!bv)
		return;

	if (meshes_.empty())
		return;

	if (meshes_.back().n_vertices() == 0)
		return;

	if (meshes_.back().n_edges() == 0)
		return;

	for(auto it=meshes_.back().faces_begin(); it !=meshes_.back().faces_end(); it++)
    {
        OpenMesh::FaceHandle face = *it;
        glBegin(GL_LINE_LOOP);
        for (auto fh_it=meshes_.back().fh_begin(face); fh_it!=meshes_.back().fh_end(face); fh_it++)
        {
            auto he = *fh_it;
            auto vertex = meshes_.back().to_vertex_handle(he);
            glNormal3fv(meshes_.back().normal(vertex).data());
            glVertex3fv(meshes_.back().point(vertex).data());
        }
        glEnd();
    }
}

void RenderingWidget::DrawFace(bool bv)
{
	if (!bv)
		return;

	if (meshes_.empty())
		return;

	if (meshes_.back().n_vertices() == 0)
		return;

	if (meshes_.back().n_faces() == 0)
		return;

	glBegin(GL_QUADS);
    for(auto it=meshes_.back().faces_begin(); it !=meshes_.back().faces_end(); it++)
    {
        OpenMesh::FaceHandle face = *it;
        for (auto fh_it=meshes_.back().fh_begin(face); fh_it!=meshes_.back().fh_end(face); fh_it++)
        {
            auto he = *fh_it;
            auto vertex = meshes_.back().to_vertex_handle(he);
            glNormal3fv(meshes_.back().normal(vertex).data());
            glVertex3fv(meshes_.back().point(vertex).data());
        }
    }
    glEnd();
}

void RenderingWidget::DrawAxis(bool bv)
{
	if (!bv)
		return;

	GLfloat origin[] = { 0.0, 0.0, 0.0 };
	GLfloat axisX[] = { 1.0, 0.0, 0.0 };
	GLfloat axisY[] = { 0.0, 1.0, 0.0 };
	GLfloat axisZ[] = { 0.0, 0.0, 1.0 };
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINES);
	glVertex3fv(origin);
	glVertex3fv(axisX);
	glEnd();
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_LINES);
	glVertex3fv(origin);
	glVertex3fv(axisY);
	glEnd();
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINES);
	glVertex3fv(origin);
	glVertex3fv(axisZ);
	glEnd();
	glColor3f(1.0, 1.0, 1.0);
}

void RenderingWidget::DrawXORRect()
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0, width(), height(),0,-1,1);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glPushAttrib(GL_ENABLE_BIT);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_COLOR_LOGIC_OP);
	glLogicOp(GL_XOR);
	glColor3f(1.0, 1.0, 1.0);

	glBegin(GL_LINE_LOOP);
	glVertex2f(start_position_.x(), start_position_.y());
	glVertex2f(current_position_.x(), start_position_.y());
	glVertex2f(current_position_.x(), current_position_.y());
	glVertex2f(start_position_.x(), current_position_.y());
	glEnd();
	glDisable(GL_LOGIC_OP);

	glPopAttrib();
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}
